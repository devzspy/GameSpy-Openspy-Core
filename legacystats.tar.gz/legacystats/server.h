#include "main.h"
#include "Client.h"
void deleteClient(Client *client);
Client *getProfile(int profileid);
